# Beat-Maker-App
A beat maker using tone.js

# Construction
### Session 1 - Create Sampler & Load sounds
A simple grid (4x4) of pads was made to wire up the sampled sound to each numbered grid. A basic structure for the code was made. In the next session I'd like to experiment with running a sequenced pattern based on the numbered div. 

Basic code structure: Create Sampler & Load sounds --> create beat maker UI ---> execute running code.

### Session 2 - Basic sequencer setup and interface Design.
Basic structure and design is setup for the pads. A sequencer array was created to record the beat sequence to played on playback.

### Session 3 - Refactoring sequence for full functionality
This is probably the most tedious step. Had to refactor the code to allow the sequencer to be updated and played back extendable to other channels.

### Session 4 - Setting up instrument states